<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('spp.index')); ?>" class="text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <h2 class="font-semibold text-xl text-slate-800 leading-tight">
                Input SPP Massal Per Kelas
            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <!-- Filter Form -->
        <div class="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-slate-200">
            <form method="GET" action="<?php echo e(route('spp.massal')); ?>" class="flex flex-wrap items-end gap-4">
                <div class="w-full sm:w-64">
                    <label for="kelas_id" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Pilih Kelas</label>
                    <select id="kelas_id" name="kelas_id" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e($selectedKelasId == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama_kelas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="w-full sm:w-44">
                    <label for="bulan" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Bulan Periode</label>
                    <select id="bulan" name="bulan" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($bulan == $m ? 'selected' : ''); ?>>
                                <?php echo e(\Carbon\Carbon::createFromDate(null, $m, 1)->translatedFormat('F')); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="w-full sm:w-32">
                    <label for="tahun" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Tahun Periode</label>
                    <select id="tahun" name="tahun" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php for($y = now()->year + 1; $y >= 2024; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($tahun == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <button type="submit" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium rounded-lg transition-colors">
                    Tampilkan
                </button>
            </form>
        </div>

        <?php if($selectedKelas): ?>
            <form method="POST" action="<?php echo e(route('spp.massal.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="kelas_id" value="<?php echo e($selectedKelasId); ?>">
                <input type="hidden" name="bulan" value="<?php echo e($bulan); ?>">
                <input type="hidden" name="tahun" value="<?php echo e($tahun); ?>">

                <!-- Shared inputs -->
                <div class="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-6">
                    <h3 class="font-bold text-slate-900 mb-4">Pengaturan Pembayaran Bersama</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Nominal Per Santri Rupiah</label>
                            <input type="number" name="nominal" min="1" step="1000" value="<?php echo e(old('nominal', $defaultNominal)); ?>" class="w-full rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm" required>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Tanggal Pembayaran</label>
                            <input type="date" name="tgl_bayar" max="<?php echo e(now()->toDateString()); ?>" value="<?php echo e(old('tgl_bayar', now()->toDateString())); ?>" class="w-full rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm" required>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Catatan Tambahan</label>
                            <input type="text" name="ket" value="<?php echo e(old('ket', 'Pembayaran massal ' . $selectedKelas->nama_kelas)); ?>" class="w-full rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500 text-sm">
                        </div>
                    </div>
                </div>

                <!-- Santri Selection Table -->
                <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div class="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                        <div>
                            <h4 class="font-bold text-slate-900">Daftar Santri — <?php echo e($selectedKelas->nama_kelas); ?></h4>
                            <p class="text-xs text-slate-500">Centang santri yang akan dibayarkan</p>
                        </div>
                        <div class="flex items-center gap-2">
                            <button type="button" onclick="toggleAll(true)" class="text-xs font-medium text-emerald-700 hover:underline">Centang Semua</button>
                            <span class="text-slate-300">|</span>
                            <button type="button" onclick="toggleAll(false)" class="text-xs font-medium text-slate-500 hover:underline">Hapus Centang</button>
                        </div>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-slate-700">
                            <thead class="bg-slate-100/75 text-xs uppercase font-semibold text-slate-600 border-b border-slate-200">
                                <tr>
                                    <th class="px-4 py-3.5 text-center w-12">Pilih</th>
                                    <th class="px-6 py-3.5">NIS</th>
                                    <th class="px-6 py-3.5">Nama Santri</th>
                                    <th class="px-6 py-3.5">Wali Santri</th>
                                    <th class="px-6 py-3.5 text-center">Status Periode Ini</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-200">
                                <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $sudahBayar = $sudahBayarSiswaIds->contains($siswa->id);
                                    ?>
                                    <tr class="hover:bg-slate-50/75 transition-colors <?php echo e($sudahBayar ? 'bg-slate-50/50 opacity-70' : ''); ?>">
                                        <td class="px-4 py-3 text-center">
                                            <?php if($sudahBayar): ?>
                                                <input type="checkbox" disabled class="rounded border-slate-300 text-slate-400">
                                            <?php else: ?>
                                                <input type="checkbox" name="siswa_ids[]" value="<?php echo e($siswa->id); ?>" checked class="santri-checkbox rounded border-slate-300 text-emerald-600 focus:ring-emerald-500">
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-3 font-mono text-xs text-slate-500"><?php echo e($siswa->nis); ?></td>
                                        <td class="px-6 py-3 font-semibold text-slate-900"><?php echo e($siswa->nama_siswa); ?></td>
                                        <td class="px-6 py-3 text-slate-600"><?php echo e($siswa->nama_orang_tua); ?></td>
                                        <td class="px-6 py-3 text-center">
                                            <?php if($sudahBayar): ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                                                    Sudah Lunas
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
                                                    Belum Bayar
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="px-6 py-8 text-center text-slate-400 italic">
                                            Belum ada santri terdaftar di kelas ini.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
                        <a href="<?php echo e(route('spp.index')); ?>" class="px-5 py-2.5 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-100 transition-colors">
                            Batal
                        </a>
                        <button type="submit" class="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-sm font-medium text-white shadow-sm transition-colors">
                            Simpan Pembayaran Massal
                        </button>
                    </div>
                </div>
            </form>

            <script>
                function toggleAll(checked) {
                    document.querySelectorAll('.santri-checkbox').forEach(cb => {
                        cb.checked = checked;
                    });
                }
            </script>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/spp/massal.blade.php ENDPATH**/ ?>