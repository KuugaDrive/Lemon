<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-slate-800 leading-tight">
            Dashboard Utama
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
 <div class="bg-purple-100 rounded-xl border border-purple-200 p-6 shadow-sm">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h3 class="text-xl font-bold text-slate-900">
                        Assalamu'alaikum, <?php echo e($user->name); ?>

                    </h3>
                    <p class="text-sm text-slate-500 mt-1">
                        Sistem Informasi PAUD dan TPQ Lemon &bull; <?php echo e($today->translatedFormat('l, d F Y')); ?>

                    </p>
                </div>
                <div class="text-left md:text-right">
                    <div class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Peran Pengguna</div>
                    <div class="text-sm font-semibold text-slate-800 mt-0.5">
                        NIP <?php echo e($user->nip); ?> &bull; <?php echo e($isAdmin ? 'Administrator' : 'Guru Pengajar'); ?>

                    </div>
                </div>
            </div>
        </div>

        <?php if($isAdmin): ?>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <div class="bg-blue-100 p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Santri Aktif</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($totalSiswa)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Seluruh kelas</div>
                </div>

                <div class="bg-blue-100 p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Guru Pengajar</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($totalGuru)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Staf pendidik</div>
                </div>

                <div class="bg-blue-100 p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Rombel Kelas</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($totalKelas)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Kelas aktif</div>
                </div>

                <div class="bg-emerald-100 p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Presensi Hari Ini</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e($presensiHadirCount); ?> / <?php echo e($totalPresensiHariIni); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Santri hadir</div>
                </div>

                <div class="bg-emerald-100 p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Setoran Hari Ini</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($setoranHariIniCount)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Catatan hafalan</div>
                </div>

                <div class="bg-green-100 p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">SPP Bulan Ini</div>
                    <div class="text-lg font-bold text-emerald-700 mt-2">Rp <?php echo e(number_format($sppBulanIni, 0, ',', '.')); ?></div>
                    <div class="text-xs text-slate-400 mt-1"><?php echo e($today->translatedFormat('F Y')); ?></div>
                </div>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Santri Bimbingan</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($totalSiswa)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Kelas yang diampu</div>
                </div>

                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Kelas Diampu</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($totalKelas)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Rombel aktif</div>
                </div>

                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Presensi Hari Ini</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e($presensiHadirCount); ?> / <?php echo e($totalPresensiHariIni); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Santri hadir</div>
                </div>

                <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                    <div class="text-xs font-semibold uppercase tracking-wider text-slate-500">Setoran Hari Ini</div>
                    <div class="text-2xl font-bold text-slate-900 mt-2"><?php echo e(number_format($setoranHariIniCount)); ?></div>
                    <div class="text-xs text-slate-400 mt-1">Catatan hafalan</div>
                </div>
            </div>
        <?php endif; ?>

        <div class="bg-white-100 rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                    <h4 class="font-semibold text-slate-800 text-base">Status Presensi Kelas Hari Ini</h4>
                    <p class="text-xs text-slate-500 mt-0.5">
                        Pantauan pengisian presensi per kelas tanggal <?php echo e($today->translatedFormat('d F Y')); ?>

                    </p>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-700">
                    <thead class="bg-slate-50 text-xs font-semibold uppercase tracking-wider text-slate-600 border-b border-slate-200">
                        <tr>
                            <th class="px-6 py-3.5 w-12 text-center">No</th>
                            <th class="px-6 py-3.5">Nama Kelas</th>
                            <?php if($isAdmin): ?>
                                <th class="px-6 py-3.5">Guru Pengampu</th>
                            <?php endif; ?>
                            <th class="px-6 py-3.5 text-center">Jumlah Santri</th>
                            <th class="px-6 py-3.5">Status Presensi</th>
                            <th class="px-6 py-3.5 text-right">Tindakan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php $__empty_1 = true; $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-slate-50/75 transition-colors">
                                <td class="px-6 py-4 text-center font-mono text-xs text-slate-400"><?php echo e($idx + 1); ?></td>
                                <td class="px-6 py-4 font-bold text-slate-900"><?php echo e($k['nama_kelas']); ?></td>
                                <?php if($isAdmin): ?>
                                    <td class="px-6 py-4 text-slate-600 text-xs"><?php echo e($k['guru_names']); ?></td>
                                <?php endif; ?>
                                <td class="px-6 py-4 text-center font-semibold text-slate-800"><?php echo e($k['total_siswa']); ?></td>
                                <td class="px-6 py-4">
                                    <?php if($k['terisi']): ?>
                                        <span class="text-emerald-700 font-semibold text-xs">
                                            Tercatat: <?php echo e($k['hadir']); ?> Hadir, <?php echo e($k['izin']); ?> Izin, <?php echo e($k['sakit']); ?> Sakit, <?php echo e($k['alfa']); ?> Alfa
                                        </span>
                                    <?php else: ?>
                                        <span class="text-amber-700 font-semibold text-xs">
                                            Belum diisi
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <a href="<?php echo e(route('presensi.index', ['kelas_id' => $k['id'], 'tanggal' => $today->toDateString()])); ?>" class="inline-flex items-center px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors">
                                        Buka Presensi
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e($isAdmin ? 6 : 5); ?>" class="px-6 py-8 text-center text-slate-400 text-xs italic">
                                    Belum ada data kelas terdaftar.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/dashboard.blade.php ENDPATH**/ ?>