<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-slate-800 leading-tight">
            Rekapitulasi Presensi Bulanan
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <!-- Filter Bar -->
        <div class="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-slate-200">
            <form method="GET" action="<?php echo e(route('presensi.rekap')); ?>" class="flex flex-wrap items-end gap-4">
                <div class="w-full sm:w-64">
                    <label for="kelas_id" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                        Pilih Kelas
                    </label>
                    <select id="kelas_id" name="kelas_id" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php $__empty_1 = true; $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e($selectedKelasId == $k->id ? 'selected' : ''); ?>>
                                <?php echo e($k->nama_kelas); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">Tidak ada kelas</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="w-full sm:w-40">
                    <label for="bulan" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                        Bulan
                    </label>
                    <select id="bulan" name="bulan" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($bulan == $m ? 'selected' : ''); ?>>
                                <?php echo e(\Carbon\Carbon::createFromDate(null, $m, 1)->translatedFormat('F')); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="w-full sm:w-32">
                    <label for="tahun" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                        Tahun
                    </label>
                    <select id="tahun" name="tahun" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php for($y = now()->year + 1; $y >= 2024; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($tahun == $y ? 'selected' : ''); ?>>
                                <?php echo e($y); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="flex items-center gap-2">
                    <button type="submit" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium rounded-lg transition-colors">
                        Tampilkan
                    </button>
                    <a href="<?php echo e(route('presensi.index', ['kelas_id' => $selectedKelasId])); ?>" class="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 text-sm font-medium rounded-lg transition-colors">
                        Input Hari Ini
                    </a>
                </div>
            </form>
        </div>

        <!-- Rekap Table -->
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div>
                    <h3 class="font-bold text-slate-900"><?php echo e($selectedKelas ? $selectedKelas->nama_kelas : 'Pilih Kelas'); ?></h3>
                    <p class="text-xs text-slate-500 mt-0.5">Periode: <span class="font-semibold text-slate-700"><?php echo e($namaBulan); ?> <?php echo e($tahun); ?></span></p>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-700">
                    <thead class="bg-slate-100/75 text-xs uppercase font-semibold text-slate-600 border-b border-slate-200">
                        <tr>
                            <th class="px-4 py-3.5 text-center w-12">No</th>
                            <th class="px-6 py-3.5">Nama Santri</th>
                            <th class="px-4 py-3.5 text-center text-emerald-700">Hadir</th>
                            <th class="px-4 py-3.5 text-center text-blue-700">Izin</th>
                            <th class="px-4 py-3.5 text-center text-amber-700">Sakit</th>
                            <th class="px-4 py-3.5 text-center text-rose-700">Alfa</th>
                            <th class="px-6 py-3.5 text-center">Total Hari</th>
                            <th class="px-6 py-3.5 text-center">% Kehadiran</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php $__empty_1 = true; $__currentLoopData = $rekapData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-slate-50/75 transition-colors">
                                <td class="px-4 py-3 text-center text-slate-400 font-mono text-xs"><?php echo e($index + 1); ?></td>
                                <td class="px-6 py-3">
                                    <a href="<?php echo e(route('presensi.siswa', ['siswa' => $row->siswa->id, 'bulan' => $bulan, 'tahun' => $tahun])); ?>" class="font-semibold text-slate-900 hover:text-emerald-700 hover:underline">
                                        <?php echo e($row->siswa->nama_siswa); ?>

                                    </a>
                                    <div class="text-xs text-slate-400 font-mono">NIS: <?php echo e($row->siswa->nis); ?></div>
                                </td>
                                <td class="px-4 py-3 text-center font-bold text-emerald-700"><?php echo e($row->hadir); ?></td>
                                <td class="px-4 py-3 text-center font-semibold text-blue-700"><?php echo e($row->izin); ?></td>
                                <td class="px-4 py-3 text-center font-semibold text-amber-700"><?php echo e($row->sakit); ?></td>
                                <td class="px-4 py-3 text-center font-semibold text-rose-700"><?php echo e($row->alfa); ?></td>
                                <td class="px-6 py-3 text-center font-mono text-slate-700"><?php echo e($row->total_hari); ?></td>
                                <td class="px-6 py-3 text-center">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold <?php echo e($row->persentase >= 80 ? 'bg-emerald-100 text-emerald-800' : ($row->persentase >= 50 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800')); ?>">
                                        <?php echo e($row->persentase); ?>%
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="px-6 py-8 text-center text-slate-400 italic">
                                    Tidak ada data santri pada kelas ini.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/presensi/rekap.blade.php ENDPATH**/ ?>