<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('master.siswa.index')); ?>" class="text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <h2 class="font-semibold text-xl text-slate-800 leading-tight">
                Profil Santri: <?php echo e($siswa->nama_siswa); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="max-w-4xl mx-auto space-y-6">
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 p-6 sm:p-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="space-y-4">
                    <h3 class="font-semibold text-slate-900 border-b border-slate-200 pb-2 text-sm uppercase tracking-wider">
                        Data Santri
                    </h3>
                    <dl class="space-y-3 text-sm">
                        <div>
                            <dt class="text-slate-500">NIS</dt>
                            <dd class="font-semibold font-mono text-slate-900 mt-0.5"><?php echo e($siswa->nis); ?></dd>
                        </div>
                        <div>
                            <dt class="text-slate-500">Nama Lengkap</dt>
                            <dd class="font-medium text-slate-900 mt-0.5"><?php echo e($siswa->nama_siswa); ?></dd>
                        </div>
                        <div>
                            <dt class="text-slate-500">Kelas</dt>
                            <dd class="font-medium text-slate-900 mt-0.5"><?php echo e($siswa->kelas->nama_kelas ?? '-'); ?></dd>
                        </div>
                        <div>
                            <dt class="text-slate-500">Tanggal Terdaftar</dt>
                            <dd class="text-slate-700 mt-0.5"><?php echo e($siswa->created_at ? $siswa->created_at->translatedFormat('d F Y') : '-'); ?></dd>
                        </div>
                    </dl>
                </div>

                <div class="space-y-4">
                    <h3 class="font-semibold text-slate-900 border-b border-slate-200 pb-2 text-sm uppercase tracking-wider">
                        Data Orang Tua
                    </h3>
                    <dl class="space-y-3 text-sm">
                        <div>
                            <dt class="text-slate-500">Nama Ayah Kandung</dt>
                            <dd class="font-medium text-slate-900 mt-0.5"><?php echo e($siswa->nama_ayah_kandung ?: '-'); ?></dd>
                        </div>
                        <div>
                            <dt class="text-slate-500">Nama Ibu Kandung</dt>
                            <dd class="font-medium text-slate-900 mt-0.5"><?php echo e($siswa->nama_ibu_kandung ?: '-'); ?></dd>
                        </div>
                        <div>
                            <dt class="text-slate-500">Nomor HP Ortu</dt>
                            <dd class="font-mono text-slate-900 mt-0.5">
                                <?php if($siswa->no_hp_ortu): ?>
                                    <a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $siswa->no_hp_ortu)); ?>" target="_blank" class="text-emerald-600 hover:text-emerald-800 hover:underline">
                                        <?php echo e($siswa->no_hp_ortu); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-slate-400">Tidak ada nomor</span>
                                <?php endif; ?>
                            </dd>
                        </div>
                        <div>
                            <dt class="text-slate-500">Alamat</dt>
                            <dd class="text-slate-800 mt-0.5 leading-relaxed"><?php echo e($siswa->alamat ?: '-'); ?></dd>
                        </div>
                    </dl>
                </div>
            </div>

            <div class="mt-8 pt-4 border-t border-slate-200 flex justify-between items-center">
                <a href="<?php echo e(route('master.siswa.index')); ?>" class="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors">
                    Kembali
                </a>

                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                    <div class="flex items-center gap-2">
                        <a href="<?php echo e(route('master.siswa.edit', $siswa)); ?>" class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                            </svg>
                            <span>Ubah Data</span>
                        </a>
                        <form method="POST" action="<?php echo e(route('master.siswa.destroy', $siswa)); ?>" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data santri <?php echo e($siswa->nama_siswa); ?>?');" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-sm font-medium transition-colors">
                                Hapus Santri
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/master/siswa/show.blade.php ENDPATH**/ ?>