<?php $__env->startSection('content'); ?>
<table class="data-table">
    <thead>
        <tr>
            <th style="width: 4%;" class="text-center">No</th>
            <th style="width: 12%;">Tgl Uji</th>
            <th style="width: 12%;">NIS</th>
            <th>Nama Santri</th>
            <th>Wali Santri</th>
            <th style="width: 16%;">Huruf Hijaiyah</th>
            <th style="width: 16%;">Jilid & Halaman</th>
            <th style="width: 8%;" class="text-center">Nilai</th>
            <th style="width: 14%;">Penguji</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-center font-mono"><?php echo e($idx + 1); ?></td>
                <td><?php echo e($item->tgl_pengujian->translatedFormat('d M Y')); ?></td>
                <td class="font-mono"><?php echo e($item->siswa->nis); ?></td>
                <td class="font-bold"><?php echo e($item->siswa->nama_siswa); ?></td>
                <td><?php echo e($item->siswa->nama_wali); ?></td>
                <td><?php echo e($item->alfabet->nama_alfabet); ?></td>
                <td><?php echo e($item->jilid); ?> — Hal. <?php echo e($item->halaman); ?></td>
                <td class="text-center">
                    <span class="badge-<?php echo e(strtolower($item->nilai->value)); ?>"><?php echo e($item->nilai->value); ?></span>
                </td>
                <td><?php echo e($item->guru?->name ?: '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9" class="text-center" style="padding: 16px; color: #94a3b8; font-style: italic;">
                    Belum ada catatan baca buku pada rentang tanggal ini.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laporan.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zum95\Lemon\resources\views/laporan/pdf/baca_buku_kelas.blade.php ENDPATH**/ ?>