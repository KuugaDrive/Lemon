<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['nilai']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['nilai']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $enumVal = $nilai instanceof \App\Enums\Penilaian ? $nilai : \App\Enums\Penilaian::tryFrom($nilai);
?>

<?php if($enumVal): ?>
    <span <?php echo e($attributes->merge(['class' => 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ' . $enumVal->badgeClass()])); ?> title="<?php echo e($enumVal->deskripsi()); ?>">
        <?php echo e($enumVal->value); ?>

    </span>
<?php else: ?>
    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 text-slate-600">
        <?php echo e($nilai); ?>

    </span>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/components/badge-nilai.blade.php ENDPATH**/ ?>