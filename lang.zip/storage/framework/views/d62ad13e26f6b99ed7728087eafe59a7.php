<?php $__env->startSection('content'); ?>
<table class="data-table">
    <thead>
        <tr>
            <th style="width: 4%;" class="text-center">No</th>
            <th style="width: 14%;">NIS</th>
            <th>Nama Santri</th>
            <th style="width: 10%;" class="text-center">Hadir</th>
            <th style="width: 10%;" class="text-center">Izin</th>
            <th style="width: 10%;" class="text-center">Sakit</th>
            <th style="width: 10%;" class="text-center">Alfa</th>
            <th style="width: 12%;" class="text-center">Total Hari</th>
            <th style="width: 12%;" class="text-center">% Kehadiran</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rekapData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-center font-mono"><?php echo e($idx + 1); ?></td>
                <td class="font-mono"><?php echo e($row->siswa->nis); ?></td>
                <td class="font-bold"><?php echo e($row->siswa->nama_siswa); ?></td>
                <td class="text-center"><?php echo e($row->hadir); ?></td>
                <td class="text-center"><?php echo e($row->izin); ?></td>
                <td class="text-center"><?php echo e($row->sakit); ?></td>
                <td class="text-center"><?php echo e($row->alfa); ?></td>
                <td class="text-center font-mono"><?php echo e($row->total_hari); ?></td>
                <td class="text-center font-bold">
                    <?php echo e($row->persentase); ?>%
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9" class="text-center" style="padding: 16px; color: #94a3b8; font-style: italic;">
                    Tidak ada santri terdaftar pada kelas ini.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laporan.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zum95\Lemon\resources\views/laporan/pdf/presensi_kelas.blade.php ENDPATH**/ ?>