<?php $__env->startSection('content'); ?>
<?php
    $totalNominal = $items->sum('nominal');
?>

<div style="margin-bottom: 12px; padding: 8px; background-color: #ecfdf5; border: 1px solid #a7f3d0; text-align: right; font-size: 9pt;">
    Total Terbayar: <strong style="font-size: 11pt; color: #065f46;">Rp <?php echo e(number_format($totalNominal, 0, ',', '.')); ?></strong>
</div>

<table class="data-table">
    <thead>
        <tr>
            <th style="width: 5%;" class="text-center">No</th>
            <th style="width: 18%;">Tgl Bayar</th>
            <th style="width: 25%;">Periode Bulan & Tahun</th>
            <th style="width: 20%;" class="text-right">Nominal</th>
            <th>Keterangan</th>
            <th style="width: 18%;">Petugas</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-center font-mono"><?php echo e($idx + 1); ?></td>
                <td><?php echo e($item->tgl_bayar->translatedFormat('d F Y')); ?></td>
                <td class="font-bold"><?php echo e($item->periode_label); ?></td>
                <td class="text-right font-mono"><?php echo e($item->nominal_rupiah); ?></td>
                <td><?php echo e($item->ket ?: '-'); ?></td>
                <td><?php echo e($item->pencatat?->name ?: '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center" style="padding: 16px; color: #94a3b8; font-style: italic;">
                    Belum ada catatan pembayaran SPP pada rentang tanggal ini.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laporan.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zum95\Lemon\resources\views/laporan/pdf/spp_siswa.blade.php ENDPATH**/ ?>