<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('spp.index')); ?>" class="text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <h2 class="font-semibold text-xl text-slate-800 leading-tight">
                Pengaturan Default SPP
            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="max-w-2xl mx-auto">
        <div class="bg-white p-6 sm:p-8 rounded-xl shadow-sm border border-slate-200">
            <div class="mb-6 pb-4 border-b border-slate-100">
                <h3 class="font-bold text-slate-900 text-lg">Konfigurasi Nilai & Jatuh Tempo</h3>
                <p class="text-xs text-slate-500 mt-1">
                    Nilai default ini digunakan sebagai rekomendasi awal pada form input SPP satuan dan massal, serta acuan kalkulasi potensi tunggakan.
                </p>
            </div>

            <form method="POST" action="<?php echo e(route('spp.pengaturan.simpan')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Nominal Default -->
                <div>
                    <label for="spp_nominal_default" class="block text-sm font-semibold text-slate-700 mb-1">
                        Nominal SPP Default Per Bulan Rupiah <span class="text-rose-500">*</span>
                    </label>
                    <input type="number" id="spp_nominal_default" name="spp_nominal_default" min="1000" step="1000" value="<?php echo e(old('spp_nominal_default', $nominalDefault)); ?>" class="w-full rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500 <?php $__errorArgs = ['spp_nominal_default'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <p class="text-xs text-slate-400 mt-1">Contoh: 150000 untuk Rp 150.000,-</p>
                    <?php $__errorArgs = ['spp_nominal_default'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-rose-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Jatuh Tempo -->
                <div>
                    <label for="spp_jatuh_tempo_hari" class="block text-sm font-semibold text-slate-700 mb-1">
                        Tanggal Jatuh Tempo Pembayaran <span class="text-rose-500">*</span>
                    </label>
                    <input type="number" id="spp_jatuh_tempo_hari" name="spp_jatuh_tempo_hari" min="1" max="31" value="<?php echo e(old('spp_jatuh_tempo_hari', $jatuhTempo)); ?>" class="w-full rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500 <?php $__errorArgs = ['spp_jatuh_tempo_hari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <p class="text-xs text-slate-400 mt-1">Tanggal dalam bulan (1 - 31), default tanggal 10 setiap bulan.</p>
                    <?php $__errorArgs = ['spp_jatuh_tempo_hari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-rose-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <a href="<?php echo e(route('spp.index')); ?>" class="px-5 py-2.5 rounded-lg border border-slate-300 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
                        Batal
                    </a>
                    <button type="submit" class="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-sm font-medium text-white shadow-sm transition-colors">
                        Simpan Pengaturan
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/spp/pengaturan.blade.php ENDPATH**/ ?>