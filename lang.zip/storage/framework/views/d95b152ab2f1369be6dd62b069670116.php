<?php $__env->startSection('content'); ?>
<table class="data-table">
    <thead>
        <tr>
            <th style="width: 5%;" class="text-center">No</th>
            <th style="width: 20%;">Tanggal</th>
            <th style="width: 25%;">Materi Iqro</th>
            <th style="width: 15%;" class="text-center">Halaman</th>
            <th style="width: 12%;" class="text-center">Penilaian</th>
            <th>Keterangan / Catatan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-center font-mono"><?php echo e($idx + 1); ?></td>
                <td><?php echo e($item->tanggal->translatedFormat('d F Y')); ?></td>
                <td class="font-bold"><?php echo e($item->iqro->nama_iqro); ?></td>
                <td class="text-center">Hal. <?php echo e($item->halaman); ?></td>
                <td class="text-center">
                    <span class="badge-<?php echo e(strtolower($item->nilai->value)); ?>"><?php echo e($item->nilai->value); ?></span>
                </td>
                <td><?php echo e($item->ket ?: '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center" style="padding: 16px; color: #94a3b8; font-style: italic;">
                    Belum ada catatan setoran Iqro pada rentang tanggal ini.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laporan.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zum95\Lemon\resources\views/laporan/pdf/iqro_siswa.blade.php ENDPATH**/ ?>