<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center gap-2">
            <a href="<?php echo e(route('spp.index')); ?>" class="text-slate-400 hover:text-slate-600">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                </svg>
            </a>
            <h2 class="font-semibold text-xl text-slate-800 leading-tight">
                Monitoring Tunggakan SPP
            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <!-- Filter Bar -->
        <div class="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-slate-200">
            <form method="GET" action="<?php echo e(route('spp.tunggakan')); ?>" class="flex flex-wrap items-end gap-4">
                <div class="w-full sm:w-60">
                    <label for="kelas_id" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Pilih Kelas</label>
                    <select id="kelas_id" name="kelas_id" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <option value="">-- Semua Kelas --</option>
                        <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e($selectedKelasId == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama_kelas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="w-full sm:w-44">
                    <label for="bulan" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Bulan Periode</label>
                    <select id="bulan" name="bulan" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($bulan == $m ? 'selected' : ''); ?>>
                                <?php echo e(\Carbon\Carbon::createFromDate(null, $m, 1)->translatedFormat('F')); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="w-full sm:w-32">
                    <label for="tahun" class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Tahun Periode</label>
                    <select id="tahun" name="tahun" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <?php for($y = now()->year + 1; $y >= 2024; $y--): ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($tahun == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <button type="submit" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-medium rounded-lg transition-colors">
                    Tampilkan
                </button>
            </form>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="p-5 bg-white rounded-xl shadow-sm border border-slate-200">
                <span class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Periode Acuan</span>
                <div class="text-xl font-bold text-slate-900 mt-1"><?php echo e($namaBulan); ?> <?php echo e($tahun); ?></div>
                <div class="text-xs text-slate-400 mt-1">Jatuh Tempo: Setiap tgl <?php echo e($tunggakanData['jatuh_tempo_hari']); ?></div>
            </div>

            <div class="p-5 bg-amber-50 rounded-xl shadow-sm border border-amber-200">
                <span class="text-xs font-semibold text-amber-800 uppercase tracking-wider">Santri Belum Bayar</span>
                <div class="text-2xl font-bold text-amber-700 mt-1"><?php echo e($tunggakanData['total_santri']); ?> Anak</div>
                <div class="text-xs text-amber-600 mt-1">Perlu konfirmasi / penagihan</div>
            </div>

            <div class="p-5 bg-rose-50 rounded-xl shadow-sm border border-rose-200">
                <span class="text-xs font-semibold text-rose-800 uppercase tracking-wider">Potensi SPP Tertunggak</span>
                <div class="text-2xl font-bold text-rose-700 mt-1">Rp <?php echo e(number_format($tunggakanData['total_nominal'], 0, ',', '.')); ?></div>
                <div class="text-xs text-rose-600 mt-1">Asumsi default Rp <?php echo e(number_format($tunggakanData['default_nominal'], 0, ',', '.')); ?>/bulan</div>
            </div>
        </div>

        <!-- Table -->
        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-700">
                    <thead class="bg-slate-50 text-xs uppercase font-semibold text-slate-600 border-b border-slate-200">
                        <tr>
                            <th class="px-4 py-3.5 text-center w-12">No</th>
                            <th class="px-6 py-3.5">Santri</th>
                            <th class="px-6 py-3.5">Kelas</th>
                            <th class="px-6 py-3.5">Wali Santri</th>
                            <th class="px-6 py-3.5">Kontak WhatsApp</th>
                            <th class="px-6 py-3.5 text-center">Status</th>
                            <th class="px-6 py-3.5 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php $__empty_1 = true; $__currentLoopData = $tunggakanData['siswa_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $hp = preg_replace('/[^0-9]/', '', $siswa->no_hp_ortu);
                                if (str_starts_with($hp, '0')) {
                                    $hp = '62' . substr($hp, 1);
                                }
                                $pesanWa = rawurlencode("Assalamu'alaikum Warahmatullahi Wabarakatuh, Bapak/Ibu wali dari {$siswa->nama_siswa}. Mengingatkan untuk iuran SPP periode {$namaBulan} {$tahun}. Terima kasih.");
                            ?>
                            <tr class="hover:bg-slate-50/75 transition-colors">
                                <td class="px-4 py-3.5 text-center text-slate-400 font-mono text-xs"><?php echo e($index + 1); ?></td>
                                <td class="px-6 py-3.5">
                                    <a href="<?php echo e(route('spp.riwayat', $siswa)); ?>" class="font-semibold text-slate-900 hover:text-emerald-700 hover:underline">
                                        <?php echo e($siswa->nama_siswa); ?>

                                    </a>
                                    <div class="text-xs text-slate-400 font-mono">NIS: <?php echo e($siswa->nis); ?></div>
                                </td>
                                <td class="px-6 py-3.5 whitespace-nowrap text-slate-600">
                                    <?php echo e($siswa->kelas?->nama_kelas); ?>

                                </td>
                                <td class="px-6 py-3.5 text-slate-700">
                                    <?php echo e($siswa->nama_orang_tua); ?>

                                </td>
                                <td class="px-6 py-3.5 whitespace-nowrap">
                                    <?php if($siswa->no_hp_ortu): ?>
                                        <a href="https://wa.me/<?php echo e($hp); ?>?text=<?php echo e($pesanWa); ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors border border-emerald-200">
                                            <svg class="w-3.5 h-3.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                            </svg>
                                            <span><?php echo e($siswa->no_hp_ortu); ?></span>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-xs text-slate-400 italic">Tidak ada nomor</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-3.5 text-center whitespace-nowrap">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800">
                                        Belum Lunas
                                    </span>
                                </td>
                                <td class="px-6 py-3.5 text-right whitespace-nowrap">
                                    <a href="<?php echo e(route('spp.create', ['siswa_id' => $siswa->id, 'bulan' => $bulan, 'tahun' => $tahun])); ?>" class="inline-flex items-center px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors gap-1">
                                        <span>Bayar Sekarang</span>
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                                        </svg>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-8 text-center text-emerald-600 font-medium">
                                    Alhamdulillah, semua santri sudah melunasi SPP untuk periode <?php echo e($namaBulan); ?> <?php echo e($tahun); ?>!
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/spp/tunggakan.blade.php ENDPATH**/ ?>