<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-slate-800 leading-tight">
            Setoran Al-Qur'an
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <h3 class="text-lg font-bold text-slate-900">Daftar Setoran Al-Qur'an</h3>
                <p class="text-sm text-slate-500">Catatan riwayat setoran hafalan dan tilawah Al-Qur'an santri.</p>
            </div>
            <a href="<?php echo e(route('setoran.quran.create')); ?>" class="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg shadow-sm transition-colors whitespace-nowrap self-start sm:self-auto">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                <span>Tambah Setoran</span>
            </a>
        </div>
        <div class="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-slate-200">
            <form method="GET" action="<?php echo e(route('setoran.quran.index')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Kelas</label>
                    <select name="kelas_id" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <option value="">Semua Kelas</option>
                        <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e(request('kelas_id') == $k->id ? 'selected' : ''); ?>><?php echo e($k->nama_kelas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Santri</label>
                    <select name="siswa_id" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <option value="">Semua Santri</option>
                        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>" <?php echo e(request('siswa_id') == $s->id ? 'selected' : ''); ?>><?php echo e($s->nama_siswa); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Surat</label>
                    <select name="surat_id" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <option value="">Semua Surat</option>
                        <?php $__currentLoopData = $surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $su): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($su->id); ?>" <?php echo e(request('surat_id') == $su->id ? 'selected' : ''); ?>><?php echo e($su->nomor); ?>. <?php echo e($su->nama_surat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Tanggal</label>
                    <input type="date" name="dari_tanggal" value="<?php echo e(request('dari_tanggal')); ?>" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">Nilai</label>
                    <select name="nilai" class="w-full text-sm py-2 rounded-lg border-slate-300 focus:border-emerald-500 focus:ring-emerald-500" onchange="this.form.submit()">
                        <option value="">Semua Nilai</option>
                        <?php $__currentLoopData = $penilaianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->value); ?>" <?php echo e(request('nilai') == $p->value ? 'selected' : ''); ?>><?php echo e($p->label()); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
        </div>

        <?php if (isset($component)) { $__componentOriginal58b00489ae5923f9cf33314075198869 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58b00489ae5923f9cf33314075198869 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.legenda-penilaian','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('legenda-penilaian'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58b00489ae5923f9cf33314075198869)): ?>
<?php $attributes = $__attributesOriginal58b00489ae5923f9cf33314075198869; ?>
<?php unset($__attributesOriginal58b00489ae5923f9cf33314075198869); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58b00489ae5923f9cf33314075198869)): ?>
<?php $component = $__componentOriginal58b00489ae5923f9cf33314075198869; ?>
<?php unset($__componentOriginal58b00489ae5923f9cf33314075198869); ?>
<?php endif; ?>

        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm text-slate-700">
                    <thead class="bg-slate-50 text-xs uppercase font-semibold text-slate-600 border-b border-slate-200">
                        <tr>
                            <th class="px-6 py-3.5">Tanggal</th>
                            <th class="px-6 py-3.5">Santri</th>
                            <th class="px-6 py-3.5">Kelas</th>
                            <th class="px-6 py-3.5">Surat</th>
                            <th class="px-6 py-3.5">Ayat</th>
                            <th class="px-6 py-3.5">Juz</th>
                            <th class="px-6 py-3.5 text-center">Nilai</th>
                            <th class="px-6 py-3.5">Keterangan</th>
                            <th class="px-6 py-3.5">Penguji</th>
                            <th class="px-6 py-3.5 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php $__empty_1 = true; $__currentLoopData = $setorans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-slate-50 transition-colors">
                                <td class="px-6 py-3.5 font-medium text-slate-900 whitespace-nowrap">
                                    <?php echo e($item->tanggal->translatedFormat('d M Y')); ?>

                                </td>
                                <td class="px-6 py-3.5">
                                    <div class="font-semibold text-slate-900"><?php echo e($item->siswa->nama_siswa); ?></div>
                                    <div class="text-xs text-slate-400 font-mono"><?php echo e($item->siswa->nis); ?></div>
                                </td>
                                <td class="px-6 py-3.5 whitespace-nowrap text-slate-600">
                                    <?php echo e($item->siswa->kelas?->nama_kelas ?? '-'); ?>

                                </td>
                                <td class="px-6 py-3.5 font-semibold text-slate-800 whitespace-nowrap">
                                    <?php echo e($item->surat->nomor); ?>. <?php echo e($item->surat->nama_surat); ?>

                                </td>
                                <td class="px-6 py-3.5 text-slate-700 whitespace-nowrap">
                                    <?php echo e($item->ayat_mulai); ?> s/d <?php echo e($item->ayat_selesai); ?>

                                </td>
                                <td class="px-6 py-3.5 text-slate-600 font-mono whitespace-nowrap">
                                    Juz <?php echo e($item->juz); ?>

                                </td>
                                <td class="px-6 py-3.5 text-center whitespace-nowrap">
                                    <?php if (isset($component)) { $__componentOriginale2e7490d6e574adda9af0a7318507178 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale2e7490d6e574adda9af0a7318507178 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-nilai','data' => ['nilai' => $item->nilai]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-nilai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nilai' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->nilai)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale2e7490d6e574adda9af0a7318507178)): ?>
<?php $attributes = $__attributesOriginale2e7490d6e574adda9af0a7318507178; ?>
<?php unset($__attributesOriginale2e7490d6e574adda9af0a7318507178); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale2e7490d6e574adda9af0a7318507178)): ?>
<?php $component = $__componentOriginale2e7490d6e574adda9af0a7318507178; ?>
<?php unset($__componentOriginale2e7490d6e574adda9af0a7318507178); ?>
<?php endif; ?>
                                </td>
                                <td class="px-6 py-3.5 text-slate-600 max-w-xs truncate">
                                    <?php echo e($item->ket ?: '-'); ?>

                                </td>
                                <td class="px-6 py-3.5 text-xs text-slate-500 whitespace-nowrap">
                                    <?php echo e($item->guru?->name); ?>

                                </td>
                                <td class="px-6 py-3.5 text-right whitespace-nowrap space-x-2">
                                    <a href="<?php echo e(route('setoran.quran.edit', $item)); ?>" class="text-xs font-semibold text-amber-600 hover:text-amber-800">Ubah</a>
                                    <form method="POST" action="<?php echo e(route('setoran.quran.destroy', $item)); ?>" class="inline" onsubmit="return confirm('Yakin ingin menghapus catatan setoran ini?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-xs font-semibold text-rose-600 hover:text-rose-800">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="px-6 py-8 text-center text-slate-400">
                                    Belum ada data setoran Al-Qur'an.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($setorans->hasPages()): ?>
                <div class="px-6 py-4 border-t border-slate-200">
                    <?php echo e($setorans->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/setoran/quran/index.blade.php ENDPATH**/ ?>