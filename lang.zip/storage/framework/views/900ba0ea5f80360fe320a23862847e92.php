<?php if(session('success')): ?>
    <div x-data="{ show: true }" x-show="show" class="mb-6 flex items-center justify-between p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-lg shadow-sm">
        <div class="flex items-center gap-3">
            <svg class="w-5 h-5 text-emerald-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <p class="text-sm font-medium text-emerald-800"><?php echo e(session('success')); ?></p>
        </div>
        <button @click="show = false" class="text-emerald-500 hover:text-emerald-700">
            <span class="sr-only">Tutup</span>
            &times;
        </button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div x-data="{ show: true }" x-show="show" class="mb-6 flex items-center justify-between p-4 bg-rose-50 border-l-4 border-rose-500 rounded-r-lg shadow-sm">
        <div class="flex items-center gap-3">
            <svg class="w-5 h-5 text-rose-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            <p class="text-sm font-medium text-rose-800"><?php echo e(session('error')); ?></p>
        </div>
        <button @click="show = false" class="text-rose-500 hover:text-rose-700">
            <span class="sr-only">Tutup</span>
            &times;
        </button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div x-data="{ show: true }" x-show="show" class="mb-6 p-4 bg-amber-50 border-l-4 border-amber-500 rounded-r-lg shadow-sm">
        <div class="flex items-start justify-between">
            <div class="flex items-start gap-3">
                <svg class="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                </svg>
                <div>
                    <h4 class="text-sm font-semibold text-amber-800">Terdapat kesalahan pada input:</h4>
                    <ul class="mt-1 list-disc list-inside text-sm text-amber-700 space-y-0.5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <button @click="show = false" class="text-amber-500 hover:text-amber-700">
                <span class="sr-only">Tutup</span>
                &times;
            </button>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\zum95\Lemon\resources\views/components/flash-messages.blade.php ENDPATH**/ ?>