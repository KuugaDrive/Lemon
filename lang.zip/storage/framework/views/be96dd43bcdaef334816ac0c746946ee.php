<?php $__env->startSection('content'); ?>
<?php
    $hadir = $items->where('status.value', 'hadir')->count();
    $izin = $items->where('status.value', 'izin')->count();
    $sakit = $items->where('status.value', 'sakit')->count();
    $alfa = $items->where('status.value', 'alfa')->count();
    $total = $items->count();
    $persen = $total > 0 ? round(($hadir / $total) * 100) : 0;
?>

<table style="width: 100%; margin-bottom: 12px; font-size: 8.5pt;">
    <tr>
        <td style="padding: 6px; background-color: #ecfdf5; border: 1px solid #a7f3d0; text-align: center;">
            <strong>Hadir:</strong> <?php echo e($hadir); ?> Hari
        </td>
        <td style="padding: 6px; background-color: #eff6ff; border: 1px solid #bfdbfe; text-align: center;">
            <strong>Izin:</strong> <?php echo e($izin); ?> Hari
        </td>
        <td style="padding: 6px; background-color: #fffbeb; border: 1px solid #fde68a; text-align: center;">
            <strong>Sakit:</strong> <?php echo e($sakit); ?> Hari
        </td>
        <td style="padding: 6px; background-color: #fff1f2; border: 1px solid #fecdd3; text-align: center;">
            <strong>Alfa:</strong> <?php echo e($alfa); ?> Hari
        </td>
        <td style="padding: 6px; background-color: #f8fafc; border: 1px solid #cbd5e1; text-align: center;">
            <strong>% Kehadiran:</strong> <strong><?php echo e($persen); ?>%</strong>
        </td>
    </tr>
</table>

<table class="data-table">
    <thead>
        <tr>
            <th style="width: 5%;" class="text-center">No</th>
            <th style="width: 20%;">Tanggal</th>
            <th style="width: 15%;">Hari</th>
            <th style="width: 15%;" class="text-center">Status</th>
            <th>Keterangan</th>
            <th style="width: 20%;">Guru Penginput</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-center font-mono"><?php echo e($idx + 1); ?></td>
                <td><?php echo e($item->tanggal->translatedFormat('d F Y')); ?></td>
                <td><?php echo e($item->tanggal->translatedFormat('l')); ?></td>
                <td class="text-center">
                    <strong><?php echo e($item->status->label()); ?></strong>
                </td>
                <td><?php echo e($item->ket ?: '-'); ?></td>
                <td><?php echo e($item->guru?->name ?: '-'); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center" style="padding: 16px; color: #94a3b8; font-style: italic;">
                    Tidak ada catatan presensi pada rentang tanggal ini.
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('laporan.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\zum95\Lemon\resources\views/laporan/pdf/presensi_siswa.blade.php ENDPATH**/ ?>